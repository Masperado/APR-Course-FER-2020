package hr.fer.zemris.optjava.dz4.api;

public interface IFunction<T> {

	double valueAt(T point);

}
